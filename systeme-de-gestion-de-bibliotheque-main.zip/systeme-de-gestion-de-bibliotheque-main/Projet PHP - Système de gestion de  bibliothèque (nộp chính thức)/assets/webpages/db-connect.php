<?php 

$con = mysqli_connect('localhost','root','123456','weblibrary');


?>